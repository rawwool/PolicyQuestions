﻿using Questions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace Questions.Utility
{
    public class Reader
    {
        public static List<Question> Read(string excelFile, IEnumerable<string> tabs)
        {
            List<Question> listOfQUestions = new List<Question>();
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(excelFile);
            //Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[6];

            tabs.ToList().ForEach(s =>
            LoadWorksheet(listOfQUestions, xlWorkbook, s));
            

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad


            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

            return listOfQUestions;
        }

        private static void LoadWorksheet(List<Question> listOfQUestions, Excel.Workbook xlWorkbook,
            string worksheetName)
        {
            Excel._Worksheet xlWorksheet;
            Excel.Range xlRange;
            xlWorksheet = xlWorkbook.Sheets[worksheetName];
            xlRange = xlWorksheet.UsedRange;
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;

            //iterate over the rows and columns and print to the console as it appears in the file
            //excel is not zero based!!
            int answersColumnIndex = GetColumnIndex(xlRange, "Answers");
            Question parentQuestion = null;
            for (int i = 2; i <= rowCount; i++)
            {
                var reference = GetValue(xlRange, i, 1);
                if (string.IsNullOrWhiteSpace(reference)) continue;
                Question question = new Question
                {
                    Category = worksheetName,
                    Ref = reference,
                    Type = ConvertToType<enumType>(GetValue(xlRange, i, 4)),
                    ParentResponseForInvokingThisChildQuestion = GetParentResponseForInvokingThisChildQuestion(GetValue(xlRange, i, 5)),
                    DataCaptureType = ConvertToType<enumDataCaptureType>(GetValue(xlRange, i, 6)),
                    HelpText = GetValue(xlRange, i, 9),
                    ResponseChoices = GetValue(xlRange, i, answersColumnIndex).Split('\n').Where(s => s.Trim().Length > 0).ToList()
                };

                question.Text = GetValue(xlRange, i, 2);
                if (string.IsNullOrEmpty(question.Text.Trim()))
                {
                    question.Text = GetValue(xlRange, i, 3);
                    question.Parent = parentQuestion;
                    parentQuestion.Children.Add(question);
                }
                else
                {
                    parentQuestion = question;
                    listOfQUestions.Add(question);
                }
            }
            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

        }

        private static int GetColumnIndex(Excel.Range xlRange, string v)
        {
            int colCount = xlRange.Columns.Count;
            List<string> names = new List<string>();
            for (int i = 1; i <= colCount; i++)
            {
                var name = GetValue(xlRange, 1, i);
                names.Add(name);
            }
            string match = Fuzzy.GetBestMatch(names, v);
            return names.IndexOf(match) + 1;
        }


        private static string SanitiseName(string worksheetName)
        {
            worksheetName = worksheetName.Trim();
            if (worksheetName.Length > 0 && char.IsDigit(worksheetName[0]))
            {
                worksheetName = worksheetName.Split(' ').Skip(1).Aggregate((a, b) => $"{a} {b}");
            }
            return worksheetName;
        }

        private static string GetParentResponseForInvokingThisChildQuestion(string line)
        {
            //In the spreadhseet the response if enclosed in double quotes
            var result = from Match match in Regex.Matches(line, "\"([^\"]*)\"")
                         select match.ToString().Trim('"');
            return result.FirstOrDefault();
        }

        //https://stackoverflow.com/a/3877738
        private static T ConvertToType<T>(string str) where T: struct
        {
            try
            {
                str = Fuzzy.GetBestMatch(Enum.GetNames(typeof(T)).ToList(), str);
                T res = (T)Enum.Parse(typeof(T), str);
                if (!Enum.IsDefined(typeof(T), res)) return default(T);
                return res;
            }
            catch
            {
                return default(T);
            }
        }

       

        private static string GetValue(Excel.Range xlRange, int i, int j)
        {
            if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                return xlRange.Cells[i, j].Value2.ToString();
            else
                return string.Empty;
        }
    }
}
