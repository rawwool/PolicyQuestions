﻿namespace Questions.Model
{
    public enum enumType
    {
        Mandaory,
        Optional
    }
}