﻿namespace Questions.Model
{
    public enum enumDataCaptureType
    {
        RadioButton,
        DropDown,
        TextBox,
        DateTimePicker
    }
}