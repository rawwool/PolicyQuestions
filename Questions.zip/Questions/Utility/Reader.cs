﻿using Questions.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace Questions.Utility
{
    public class Reader
    {
        public static List<Question> Read(string excelFile)
        {
            List<Question> listOfQUestions = new List<Question>();
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(excelFile);
            //Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[6];
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets["1a About you"];
            Excel.Range xlRange = xlWorksheet.UsedRange;

            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;

            //iterate over the rows and columns and print to the console as it appears in the file
            //excel is not zero based!!
            Question parentQuestion = null;
            for (int i = 2; i <= rowCount; i++)
            {
                Question question = new Question
                {
                    Ref = GetValue(xlRange, i, 1),
                    Type = ConvertToType<enumType>(GetValue(xlRange, i, 4)),
                    ParentResponseForInvokingThisChildQuestion = GetParentResponseForInvokingThisChildQuestion(GetValue(xlRange, i, 5)),
                    DataCaptureType = ConvertToType<enumDataCaptureType>(GetValue(xlRange, i, 6)),
                    HelpText = GetValue(xlRange, i, 9),
                    ResponseChoices = GetValue(xlRange, i, 8).Split('\n').Where(s=>s.Trim().Length > 0).ToList()
                };
                question.Text = GetValue(xlRange, i, 2);
                if (string.IsNullOrEmpty(question.Text.Trim()))
                {
                    question.Text = GetValue(xlRange,i, 3);
                    question.Parent = parentQuestion;
                    parentQuestion.Children.Add(question);
                }
                else
                {
                    parentQuestion = question;
                    listOfQUestions.Add(question);
                }

                //for (int j = 1; j <= colCount; j++)
                //{
                //    //new line
                //    if (j == 1)
                //        Console.Write("\r\n");

                //    //write the value to the console
                //    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                //        Console.Write(xlRange.Cells[i, j].Value2.ToString() + "\t");
                //}
            }

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

            return listOfQUestions;
        }

        private static string GetParentResponseForInvokingThisChildQuestion(string line)
        {
            //In the spreadhseet the response if enclosed in double quotes
            var result = from Match match in Regex.Matches(line, "\"([^\"]*)\"")
                         select match.ToString().Trim('"');
            return result.FirstOrDefault();
        }

        //https://stackoverflow.com/a/3877738
        private static T ConvertToType<T>(string str) where T: struct
        {
            try
            {
                T res = (T)Enum.Parse(typeof(T), str);
                if (!Enum.IsDefined(typeof(T), res)) return default(T);
                return res;
            }
            catch
            {
                return default(T);
            }
        }

       

        private static string GetValue(Excel.Range xlRange, int i, int j)
        {
            if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                return xlRange.Cells[i, j].Value2.ToString();
            else
                return string.Empty;
        }
    }
}
